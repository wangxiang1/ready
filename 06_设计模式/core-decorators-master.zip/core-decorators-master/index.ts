// index.ts - facade for core-decorators
// 

export * from './lib/core-decorators';
